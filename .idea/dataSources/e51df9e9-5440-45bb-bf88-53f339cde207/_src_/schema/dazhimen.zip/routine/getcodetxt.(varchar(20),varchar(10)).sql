CREATE FUNCTION `getcodetxt`(`p_codeid` VARCHAR(20), `p_codevalue` VARCHAR(10))
  RETURNS VARCHAR(255)
begin     
    declare value varchar(255);       
    set value = '';       
    select codetext into value  from codemap where codeid = p_codeid and codevalue = p_codevalue; 
   return value; 
end