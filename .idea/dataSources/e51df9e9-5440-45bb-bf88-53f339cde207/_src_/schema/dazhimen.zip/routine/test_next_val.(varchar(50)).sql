CREATE PROCEDURE `test_next_val`(IN `p_seq_name` VARCHAR(50), OUT `r_next_val` INT(11))
  begin
start transaction; 
update sequence set current_val = (current_val + increment_val) % max_val  where seq_name = p_seq_name;
select current_val into r_next_val  from sequence where seq_name = p_seq_name;
commit;
end