CREATE FUNCTION `nextval`(`v_seq_name` VARCHAR(50))
  RETURNS INT(11)
begin
    update sequence set current_val = (current_val + increment_val) % max_val  where seq_name = v_seq_name;
    return currval(v_seq_name);
end